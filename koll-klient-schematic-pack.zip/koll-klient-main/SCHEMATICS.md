# Nexus Client – schematic reference pack

This package keeps the uploaded Fabric 1.21.11 project and adds a guide to community Litematica builds matching the requested traps.

## Schematic references

### 5x1 Flatground – Judelow style
- Community listing: https://www.minecraft-schematics.com/schematic/28979/
- Format: `.litematic`
- The listing describes it as a “5x1 Trap + Funnel & Kill Chamber” and identifies it as Judelow style.
- The site's download button currently redirects to a login page, so the schematic file could not be bundled here.

Alternative listing:
- https://www.abfielder.com/Products/ProductDetails.php?id=8151
- “5x1 Flat ground trap for hoplite by judelow”, listed as 10 × 6 × 9 blocks (379 blocks).

### Pizza Trap – Judelow style
- Community listing: https://www.minecraft-schematics.com/schematic/29228/
- Format: `.litematic`
- The listing describes it as “Pizza Trap + Funnel + Killing Chamber” and Judelow style.
- The site's download button currently redirects to a login page, so the schematic file could not be bundled here.

Alternative free listing:
- https://www.abfielder.com/Products/ProductDetails.php?id=11509
- “pizza trap” by Bensuperyigit123, listed as 13 × 6 × 10 blocks (360 blocks).

## How to use the `.litematic` files
1. Open the listing and download the `.litematic` file from the creator/site.
2. Put it in your Minecraft `schematics` folder (Litematica's schematic directory).
3. In game, open Litematica's menu, load the schematic, then create/place the schematic placement.
4. Use the material list and layer rendering to build it. Check the Minecraft version and server rules first.

## Important: what is and is not changed
- The uploaded Fabric source project is included unchanged.
- This ZIP does **not** contain the third-party `.litematic` files: their download endpoints were not accessible without site login / returned 403.
- The existing `BuilderBotModule` only has its own simple in-code build plans; it does not parse `.litematic` files. A real Litematica loader integration would need a separate implementation and testing in Minecraft.
- No compiled `.jar` is included; this package has not been built or tested in Minecraft.

Do not upload third-party schematics publicly without checking their creator's license/permission.
