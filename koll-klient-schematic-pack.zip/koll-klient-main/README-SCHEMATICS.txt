See SCHEMATICS.md for researched 5x1 and Pizza Trap Litematica references and installation notes.
