# Nexus Client (stage 1-2)

Skeleton + core architecture: event bus, modules, settings, JSON profiles.

## Build
1. Check exact versions at https://fabricmc.net/develop and update `gradle.properties`.
2. `gradle wrapper` (once), then `./gradlew build`
3. Jar: `build/libs/nexus-client-0.1.0.jar` -> `.minecraft/mods/` (needs Fabric Loader + Fabric API)
4. Dev run: `./gradlew runClient`

## Config
`.minecraft/config/nexus/profiles/NAME.json`, last-used profile in `client.json`.
