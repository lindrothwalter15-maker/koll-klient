package dev.nexus.module.modules;

import dev.nexus.event.TickEvent;
import dev.nexus.module.Category;
import dev.nexus.module.Module;
import dev.nexus.setting.ModeSetting;
import dev.nexus.setting.NumberSetting;
import dev.nexus.util.InvUtil;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Creative-mode structure builder. Structures are queued as ordered block placements:
 * floors first, then walls, so later blocks have something to attach to.
 * ShadowMC/Judlow are practical approximations, not verified copies of the videos.
 */
public final class BuilderBotModule extends Module {
    private record Entry(BlockPos pos, Block block) {}

    private final ModeSetting structure = add(new ModeSetting("Structure", "Trap layout to build", "Trap",
            "Flatground5x1", "Trap", "PizzaTrap", "ShadowMCTrap", "JudlowTrap"));
    private final ModeSetting rowBlock = add(new ModeSetting("FlatgroundBlock", "Block for 5x1 flatground", "Stone",
            "Stone", "Obsidian", "Glass", "Planks", "Wool", "Sandstone"));
    private final NumberSetting perTick = add(new NumberSetting("PerTick", "Blocks per tick", 2, 1, 6, 1));

    private final List<Entry> plan = new ArrayList<>();
    private final Map<Block, Integer> slots = new HashMap<>();
    private int stuck;

    public BuilderBotModule() {
        super("BuilderBot", "Builds selected PvP trap layouts in creative mode", Category.MISC);
        listen(TickEvent.class, e -> tick());
    }

    @Override public String getInfo() { return plan.isEmpty() ? structure.get() : plan.size() + " left"; }

    @Override
    protected void onEnable() {
        if (mc.player == null || mc.interactionManager == null) { setEnabled(false); return; }
        if (!mc.interactionManager.getCurrentGameMode().isCreative()) {
            say("BuilderBot needs creative mode.");
            setEnabled(false);
            return;
        }
        buildPlan();
        slots.clear();
        stuck = 0;
        say("BuilderBot: " + structure.get() + " - " + plan.size() + " blocks queued.");
    }

    @Override protected void onDisable() { plan.clear(); }

    private void say(String s) {
        if (mc.player != null) mc.player.sendMessage(Text.literal(s), false);
    }

    private Block rowBlockType() {
        return switch (rowBlock.get()) {
            case "Obsidian" -> Blocks.OBSIDIAN;
            case "Glass" -> Blocks.GLASS;
            case "Planks" -> Blocks.OAK_PLANKS;
            case "Wool" -> Blocks.WHITE_WOOL;
            case "Sandstone" -> Blocks.SANDSTONE;
            default -> Blocks.STONE;
        };
    }

    private void buildPlan() {
        plan.clear();
        BlockPos feet = mc.player.getBlockPos();
        Direction forward = mc.player.getHorizontalFacing();
        Direction right = forward.rotateYClockwise();
        BlockPos center = feet.down();

        switch (structure.get()) {
            case "Flatground5x1" -> {
                BlockPos rowCenter = feet.offset(forward, 2).down();
                for (int x = -2; x <= 2; x++) add(x, 0, 0, rowBlockType(), rowCenter, right, forward);
            }
            case "PizzaTrap" -> buildPizzaTrap(center, right, forward);
            case "ShadowMCTrap" -> buildSquareTrap(center, right, forward, 5, 3, true);
            case "JudlowTrap" -> buildSquareTrap(center, right, forward, 7, 2, false);
            default -> buildSquareTrap(center, right, forward, 5, 3, false);
        }
    }

    /** Standard 5x5 obsidian platform and 3-block-high perimeter. */
    private void buildSquareTrap(BlockPos center, Direction right, Direction forward,
                                 int width, int wallHeight, boolean cornerPillars) {
        int radius = width / 2;
        // Base first, so the wall placements can attach to it.
        for (int x = -radius; x <= radius; x++) {
            for (int z = -radius; z <= radius; z++) {
                add(x, 0, z, Blocks.OBSIDIAN, center, right, forward);
            }
        }
        for (int y = 1; y <= wallHeight; y++) {
            for (int x = -radius; x <= radius; x++) {
                for (int z = -radius; z <= radius; z++) {
                    boolean edge = Math.abs(x) == radius || Math.abs(z) == radius;
                    if (edge) add(x, y, z, Blocks.OBSIDIAN, center, right, forward);
                }
            }
        }
        if (cornerPillars) {
            for (int y = wallHeight + 1; y <= wallHeight + 2; y++) {
                for (int x : new int[]{-radius, radius}) {
                    for (int z : new int[]{-radius, radius}) {
                        add(x, y, z, Blocks.OBSIDIAN, center, right, forward);
                    }
                }
            }
        }
    }

    /** Pizza-pattern floor surrounded by a three-block-high obsidian ring. */
    private void buildPizzaTrap(BlockPos center, Direction right, Direction forward) {
        int radius = 3;
        for (int x = -radius; x <= radius; x++) {
            for (int z = -radius; z <= radius; z++) {
                int d2 = x * x + z * z;
                if (d2 > radius * radius + 1) continue;
                Block floor;
                if (d2 >= 8) floor = Blocks.ORANGE_TERRACOTTA; // crust
                else if (d2 <= 2 && ((x + z) & 1) == 0) floor = Blocks.RED_CONCRETE; // pepperoni
                else floor = Blocks.YELLOW_CONCRETE; // cheese
                add(x, 0, z, floor, center, right, forward);
            }
        }
        // Follow the round edge with obsidian walls; floors are queued first.
        for (int y = 1; y <= 3; y++) {
            for (int x = -radius; x <= radius; x++) {
                for (int z = -radius; z <= radius; z++) {
                    int d2 = x * x + z * z;
                    if (d2 >= 8 && d2 <= 10) add(x, y, z, Blocks.OBSIDIAN, center, right, forward);
                }
            }
        }
    }

    private void add(int x, int y, int z, Block block, BlockPos center, Direction right, Direction forward) {
        BlockPos p = center.offset(right, x).offset(forward, z).up(y);
        plan.add(new Entry(p, block));
    }

    private void tick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null || plan.isEmpty()) return;
        int placed = 0;
        Iterator<Entry> it = plan.iterator();
        while (it.hasNext() && placed < perTick.asInt()) {
            Entry e = it.next();
            BlockState state = mc.world.getBlockState(e.pos());
            if (state.isOf(e.block()) || !state.isReplaceable()) { it.remove(); continue; }
            if (tryPlace(e)) { it.remove(); placed++; }
        }
        if (plan.isEmpty()) {
            say("BuilderBot: done.");
            setEnabled(false);
            return;
        }
        stuck = placed == 0 ? stuck + 1 : 0;
        if (stuck > 60) {
            say("BuilderBot stopped: " + plan.size() + " blocks remain (out of reach or no attach surface).");
            setEnabled(false);
        }
    }

    private boolean tryPlace(Entry e) {
        BlockPos p = e.pos();
        if (mc.player.getEyePos().squaredDistanceTo(Vec3d.ofCenter(p)) > 27.0) return false;
        if (mc.player.getBoundingBox().intersects(p.getX(), p.getY(), p.getZ(), p.getX() + 1, p.getY() + 1, p.getZ() + 1)) return false;

        for (Direction d : Direction.values()) {
            BlockPos neighbor = p.offset(d);
            BlockState neighborState = mc.world.getBlockState(neighbor);
            if (neighborState.isAir() || neighborState.isReplaceable()) continue;
            InvUtil.select(hotbarSlotFor(e.block()));
            Direction face = d.getOpposite();
            Vec3d hit = Vec3d.ofCenter(neighbor).add(face.getOffsetX() * 0.5, face.getOffsetY() * 0.5, face.getOffsetZ() * 0.5);
            mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND,
                    new BlockHitResult(hit, face, neighbor, false));
            mc.player.swingHand(Hand.MAIN_HAND);
            return true;
        }
        return false;
    }

    /** Hotbar slot (2-8); creative inventory supplies blocks when needed. */
    private int hotbarSlotFor(Block block) {
        int slot = slots.computeIfAbsent(block, b -> 2 + (slots.size() % 7));
        var item = block.asItem();
        if (!mc.player.getInventory().getStack(slot).isOf(item)) {
            mc.interactionManager.clickCreativeStack(new ItemStack(item, 64), 36 + slot);
        }
        return slot;
    }
}
