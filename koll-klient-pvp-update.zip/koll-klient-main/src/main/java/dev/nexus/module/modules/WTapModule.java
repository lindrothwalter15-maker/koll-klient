package dev.nexus.module.modules;

import dev.nexus.event.TickEvent;
import dev.nexus.module.Category;
import dev.nexus.module.Module;
import dev.nexus.setting.NumberSetting;

/**
 * Sprint-reset helper after an attack. It briefly disables sprint, then lets
 * normal movement input resume it. This does not synthesize keyboard input.
 */
public final class WTapModule extends Module {
    private final NumberSetting resetTicks = add(new NumberSetting(
            "Reset ticks", "Ticks to keep sprint disabled after a hit", 1, 1, 4, 1));
    private float previousCooldown = 1.0f;
    private int resetRemaining;

    public WTapModule() {
        super("W-Tap", "Briefly resets sprint after an attack", Category.COMBAT);
        listen(TickEvent.class, e -> tick());
    }

    private void tick() {
        if (mc.player == null) {
            resetRemaining = 0;
            previousCooldown = 1.0f;
            return;
        }

        float cooldown = mc.player.getAttackCooldownProgress(0.0f);
        // A drop from a ready attack to a low cooldown indicates a recent hit.
        if (previousCooldown >= 0.9f && cooldown < 0.2f) {
            resetRemaining = resetTicks.asInt();
            mc.player.setSprinting(false);
        }

        if (resetRemaining > 0) {
            mc.player.setSprinting(false);
            resetRemaining--;
        }

        previousCooldown = cooldown;
    }

    @Override
    protected void onDisable() {
        resetRemaining = 0;
    }
}
