package dev.nexus.module.modules;

import dev.nexus.event.TickEvent;
import dev.nexus.module.Category;
import dev.nexus.module.Module;
import dev.nexus.setting.NumberSetting;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;

/**
 * Attacks a player only while that player is directly under the crosshair.
 * Intended for private/test worlds; servers may prohibit automated attacks.
 */
public final class TriggerBotModule extends Module {
    private final NumberSetting delay = add(new NumberSetting(
            "Delay (ms)", "Minimum time between automatic attacks", 120, 0, 1000, 10));
    private long lastAttack;

    public TriggerBotModule() {
        super("TriggerBot", "Automatically attacks a player under your crosshair", Category.COMBAT);
        listen(TickEvent.class, e -> tick());
    }

    private void tick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (!(mc.crosshairTarget instanceof EntityHitResult hit)) return;
        if (!(hit.getEntity() instanceof PlayerEntity target)) return;
        if (target == mc.player || !target.isAlive()) return;

        long now = System.currentTimeMillis();
        if (now - lastAttack < delay.asInt()) return;
        if (mc.player.getAttackCooldownProgress(0.0f) < 1.0f) return;

        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(net.minecraft.util.Hand.MAIN_HAND);
        lastAttack = now;
    }
}
