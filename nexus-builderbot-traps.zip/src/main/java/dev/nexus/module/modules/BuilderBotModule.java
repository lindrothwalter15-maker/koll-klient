package dev.nexus.module.modules;

import dev.nexus.event.TickEvent;
import dev.nexus.module.Category;
import dev.nexus.module.Module;
import dev.nexus.setting.ModeSetting;
import dev.nexus.setting.NumberSetting;
import dev.nexus.util.InvUtil;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/** Builds selectable PvP practice structures in front of the player (creative mode only). */
public final class BuilderBotModule extends Module {
    private record Entry(BlockPos pos, Block block) {}

    private final ModeSetting structure = add(new ModeSetting("Structure", "Choose a build template", "PizzaTrap",
            "Flatground5x1", "ShadowTrap", "JudlowTrap", "PizzaTrap", "Pizza"));
    private final ModeSetting rowBlock = add(new ModeSetting("RowBlock", "Block for flatground", "Obsidian",
            "Stone", "Obsidian", "Glass", "Planks", "Wool", "Sandstone"));
    private final NumberSetting perTick = add(new NumberSetting("PerTick", "Blocks per tick", 2, 1, 6, 1));

    private final List<Entry> plan = new ArrayList<>();
    private final Map<Block, Integer> slots = new HashMap<>();
    private int stuck;

    public BuilderBotModule() {
        super("BuilderBot", "Builds selectable PvP practice structures", Category.MISC);
        listen(TickEvent.class, e -> tick());
    }

    @Override public String getInfo() { return plan.isEmpty() ? "" : plan.size() + " left"; }

    @Override protected void onEnable() {
        if (mc.player == null || mc.interactionManager == null) { setEnabled(false); return; }
        if (!mc.interactionManager.getCurrentGameMode().isCreative()) {
            say("BuilderBot needs creative mode."); setEnabled(false); return;
        }
        buildPlan(); slots.clear(); stuck = 0;
        say("Building " + structure.get() + " (" + plan.size() + " blocks)...");
    }

    @Override protected void onDisable() { plan.clear(); }
    private void say(String s) { if (mc.player != null) mc.player.sendMessage(Text.literal(s), false); }

    private Block rowBlockType() {
        return switch (rowBlock.get()) {
            case "Obsidian" -> Blocks.OBSIDIAN;
            case "Glass" -> Blocks.GLASS;
            case "Planks" -> Blocks.OAK_PLANKS;
            case "Wool" -> Blocks.WHITE_WOOL;
            case "Sandstone" -> Blocks.SANDSTONE;
            default -> Blocks.STONE;
        };
    }

    private void add(BlockPos p, Block b) { plan.add(new Entry(p, b)); }

    private void buildPlan() {
        plan.clear();
        BlockPos feet = mc.player.getBlockPos();
        Direction f = mc.player.getHorizontalFacing();
        Direction r = f.rotateYClockwise();
        int y = feet.getY();

        if (structure.is("Flatground5x1")) {
            BlockPos c = feet.offset(f, 3);
            for (int i = -2; i <= 2; i++) add(c.offset(r, i), rowBlockType());
            return;
        }

        // The two named styles are distinct compact practice layouts, not exact reproductions
        // of the videos: no readable schematic files were supplied with the project.
        BlockPos c = feet.offset(f, 5);
        if (structure.is("Pizza")) {
            pizzaFloor(c, y, r, f, 2);
            return;
        }
        if (structure.is("PizzaTrap")) {
            pizzaFloor(c, y, r, f, 2);
            // Two-block-high obsidian perimeter around the pizza floor.
            for (int h = 1; h <= 2; h++) for (int x = -2; x <= 2; x++) for (int z = -2; z <= 2; z++) {
                if (Math.abs(x) == 2 || Math.abs(z) == 2)
                    add(c.offset(r, x).offset(f, z).up(h), Blocks.OBSIDIAN);
            }
            return;
        }

        // Flat 5x5 floor first, then a 2-high perimeter and a partial roof.
        // ShadowTrap: full perimeter + roof ring. JudlowTrap: wider entrance gap + roof ring.
        for (int x = -2; x <= 2; x++) for (int z = -2; z <= 2; z++)
            add(c.offset(r, x).offset(f, z), Blocks.OBSIDIAN);
        for (int h = 1; h <= 2; h++) {
            for (int x = -2; x <= 2; x++) for (int z = -2; z <= 2; z++) {
                boolean edge = Math.abs(x) == 2 || Math.abs(z) == 2;
                boolean judlowDoor = structure.is("JudlowTrap") && z == -2 && x >= -1 && x <= 1 && h == 1;
                if (edge && !judlowDoor) add(c.offset(r, x).offset(f, z).up(h), Blocks.OBSIDIAN);
            }
        }
        // Roof rim, deliberately not a solid ceiling.
        for (int x = -2; x <= 2; x++) for (int z = -2; z <= 2; z++)
            if (Math.abs(x) == 2 || Math.abs(z) == 2)
                add(c.offset(r, x).offset(f, z).up(3), Blocks.OBSIDIAN);
    }

    private void pizzaFloor(BlockPos c, int y, Direction r, Direction f, int rad) {
        for (int x = -rad; x <= rad; x++) for (int z = -rad; z <= rad; z++) {
            int d2 = x * x + z * z;
            if (d2 > rad * rad + 1) continue;
            Block b;
            if (d2 > (rad - 1) * (rad - 1) + 1) b = Blocks.ORANGE_TERRACOTTA;
            else if (d2 <= 2 && ((x + z) & 1) == 0) b = Blocks.RED_CONCRETE;
            else b = Blocks.YELLOW_CONCRETE;
            add(c.offset(r, x).offset(f, z).withY(y), b);
        }
    }

    private void tick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null || plan.isEmpty()) return;
        int placed = 0;
        Iterator<Entry> it = plan.iterator();
        while (it.hasNext() && placed < perTick.asInt()) {
            Entry e = it.next();
            BlockState st = mc.world.getBlockState(e.pos());
            if (st.isOf(e.block()) || !st.isReplaceable()) { it.remove(); continue; }
            if (tryPlace(e)) placed++;
        }
        if (plan.isEmpty()) { say("BuilderBot: done."); setEnabled(false); return; }
        stuck = placed == 0 ? stuck + 1 : 0;
        if (stuck > 80) {
            say("BuilderBot stopped: " + plan.size() + " blocks remain (out of reach or no place to attach).");
            setEnabled(false);
        }
    }

    private boolean tryPlace(Entry e) {
        BlockPos p = e.pos();
        if (mc.player.getEyePos().squaredDistanceTo(Vec3d.ofCenter(p)) > 27.0) return false;
        if (mc.player.getBoundingBox().intersects(p.getX(), p.getY(), p.getZ(), p.getX() + 1, p.getY() + 1, p.getZ() + 1)) return false;
        for (Direction d : Direction.values()) {
            BlockPos n = p.offset(d);
            BlockState ns = mc.world.getBlockState(n);
            if (ns.isAir() || ns.isReplaceable()) continue;
            InvUtil.select(hotbarSlotFor(e.block()));
            Direction face = d.getOpposite();
            Vec3d hit = Vec3d.ofCenter(n).add(face.getOffsetX() * 0.5, face.getOffsetY() * 0.5, face.getOffsetZ() * 0.5);
            mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, new BlockHitResult(hit, face, n, false));
            mc.player.swingHand(Hand.MAIN_HAND);
            return true;
        }
        return false;
    }

    private int hotbarSlotFor(Block block) {
        int slot = slots.computeIfAbsent(block, b -> 2 + (slots.size() % 7));
        var item = block.asItem();
        if (!mc.player.getInventory().getStack(slot).isOf(item))
            mc.interactionManager.clickCreativeStack(new ItemStack(item, 64), 36 + slot);
        return slot;
    }
}
